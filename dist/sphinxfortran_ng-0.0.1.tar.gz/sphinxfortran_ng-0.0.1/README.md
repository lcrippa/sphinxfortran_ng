# sphinxfortran_ng
An improved version of the original sphinx-fortran python module.

This code is based on the following original software:

- [sphinx-fortran](https://gitlab.com/l_sim/sphinx-fortran), on the "l_sim" working branch
- [crackfortran](https://github.com/numpy/numpy/tree/main/numpy/f2py) from the Numpy/f2py python module
